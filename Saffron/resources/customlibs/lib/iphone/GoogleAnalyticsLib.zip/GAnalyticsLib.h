//
//  GAnalyticsLib.h
//  GAnalyticsLib
//
//  Created by Alex Louey on 16/01/2015.
//  Copyright (c) 2015 appscore. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GAnalyticsLib : NSObject
-(id)initWithProperty:(NSString*)propertyID;
-(void)trackFormWithName:(NSString*)formName;
@end
