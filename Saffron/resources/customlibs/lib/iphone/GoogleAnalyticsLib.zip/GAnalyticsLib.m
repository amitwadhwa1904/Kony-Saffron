//
//  GAnalyticsLib.m
//  GAnalyticsLib
//
//  Created by Alex Louey on 16/01/2015.
//  Copyright (c) 2015 appscore. All rights reserved.
//

#import "GAnalyticsLib.h"
#import "GAI.h"
#import "GAIFields.h"
#import "GAIDictionaryBuilder.h"

@implementation GAnalyticsLib{
    NSString* _propertyID;
}


-(id)initWithProperty:(NSString*)propertyID{
    self = [super init];
    
    if(self){
        _propertyID = propertyID;
        [GAI sharedInstance].dispatchInterval = 20;
        id<GAITracker> tracker = [[GAI sharedInstance] trackerWithTrackingId:_propertyID];
        tracker.allowIDFACollection = YES;
    }
    return self;
}

-(void)trackFormWithName:(NSString*)formName{
    id<GAITracker> tracker = [[GAI sharedInstance] trackerWithTrackingId:_propertyID];
    [tracker set:kGAIScreenName value:formName];
    [tracker send:[[GAIDictionaryBuilder createScreenView] build]];
}
@end
